from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list, name='post_list'),
    path('credits_page.html', views.credits_page, name='credits_page'),
    path('loan.html', views.loan, name='loans'),
    path('higher.html', views.higher, name='higher'),
    path('lower.html', views.lower, name='lower'),
    path('add',views.add,name="add"),

]
