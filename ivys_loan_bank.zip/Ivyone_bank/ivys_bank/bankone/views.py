from django.shortcuts import render
from django.http import HttpResponse 
from bankone.loaning_system import Loan 
from bankone.balance_management import Balance
principal=[]
m=[]
p=[]


def post_list(request):
    return render(request, 'blog/post_list.html')

def credits_page(request):
    return render(request, 'blog/credits_page.html')
def loan(request):
    return render(request, 'blog/loan.html')
def higher(request):
    return render(request, 'blog/higher.html')
def lower(request):
    return render(request, 'blog/lower.html')
# Create your views here.

def add(request):
    try:
        part=int(request.GET['principal_part'])
        if part>=500 and part<=50000:
            principal.append(part)
            loan = Loan(principal[-1], 5, 12)
            monthly_payment = loan.calculate_monthly_payment()
            return render(request,"blog/loan.html",{"part":f"You have loaned {principal[-1]},Annual interest rate: {loan.interest_rate}%, and you have to pay {monthly_payment:.2f} per month for {loan.term} months"})
        else:
            return render(request,"blog/loan.html",{"part":"We can't loan you past the limits. If you really need to call 260-206-4651, or go to home page and choose"})
    except ValueError:
        return render(request,"blog/loan.html",{"part":"We can't loan you letters"})


