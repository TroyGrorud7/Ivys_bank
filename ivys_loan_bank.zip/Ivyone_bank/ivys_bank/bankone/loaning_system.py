class Loan:
  def __init__(self, principal, interest_rate, term):
    self.principal = principal
    self.interest_rate = interest_rate
    self.term = term

  def calculate_monthly_payment(self):
    monthly_interest_rate = 1.05

    # Monthly payment formula for a fixed-rate loan
    monthly_payment = ((self.principal * monthly_interest_rate)/self.term)

    return monthly_payment


# Example usage:
#loan_amount = int(input("How much would you like to receive?"))
#interest_rate = 5.0  # Example annual interest rate
#loan_term = 12  # Example loan term in months

# Create a Loan instance
#loan = Loan(principal[-1], 5, 12)

# Calculate and print the monthly payment
#monthly_payment = loan.calculate_monthly_payment()
#print(f"Loan amount: ${loan.principal}")
#print(f"Annual interest rate: {loan.interest_rate}%")
#print(f"Loan term: {loan.term} months")
#print(f"Monthly payment: ${monthly_payment:.2f}")

